#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>
#include <errno.h>
#include <time.h>
#include <math.h>

volatile uint8_t ***generateFiles(int size)
{
    srand(time(NULL));
    volatile uint8_t ***files;

    int i, j, k;

    files = malloc(1000 * sizeof(uint8_t **));
    for (i = 0; i < 1000; i++)
    {
        files[i] = malloc(sizeof(uint8_t *) * size);
        for (j = 0; j < size; j++)
        {
            files[i][j] = malloc(sizeof(uint8_t) * size);
        }
    }


    for (i = 0; i < 1000; i++)
    {
        for (j = 0; j < size; j++)
        {
            for (k = 0; k < size; k++)
            {
                uint8_t num = (rand() % 32);
                files[i][j][k] = (uint8_t) num;
            }
        }
    }
    return files;
}

uint8_t **encryption(int *matrix, volatile uint8_t **file, int file_size, int key_size)
{
    int n_block = file_size / key_size;
    int l, m, i, j, k, sum;

    int key[(int)((key_size))][(int)(key_size)];
    for (int i = 0; i < (key_size); i++)
    {
        for (int j = 0; j < (key_size); j++)
        {
            key[i][j] = matrix[(int)(i * (key_size) + j)];
        }
    }

    if (file_size % key_size != 0)
    {
        fprintf(stderr, "Wrong key size: %d and file size: %d",key_size,file_size);
        exit(EXIT_FAILURE);
    }
    uint8_t **encrypted_file = malloc(file_size * sizeof(uint8_t*));
    for (int i = 0; i < file_size;i++)
    {
        encrypted_file[i] = malloc(sizeof(uint8_t) * file_size);
    }

    for (l = 0; l < n_block; l++)
    {
        for (m = 0; m < n_block; m++)
        {
            for (i = 0; i < key_size; i++)
            {
                for (j = 0; j < key_size; j++)
                {
                    sum = 0;
                    for (k = 0; k < key_size; k++)
                    {
                        sum += (key[i][k] * file[k + l * key_size][j + m * key_size]);
                    }
                    sum = sum%256;
                    encrypted_file[i + l * key_size][j + m * key_size] = sum;
                }
            }
        }
    }
    return encrypted_file;
}

void print_data(int *key, volatile uint8_t **matrix, uint8_t **encrypt, int file_size, int key_size)
{
    printf("Key size:%d \t File size:%d\n", key_size, file_size);
    printf("----------KEY----------\n");
    for (int i = 0; i < key_size; i++)
    {
        for (int j = 0; j < key_size; j++)
        {
            printf("%d ", key[i*key_size + j]);
        }
        printf("\n");
    }
    printf("\n--------FILE--------\n");
    for (int i = 0; i < file_size; i++)
    {
        for (int j = 0; j < file_size; j++)
        {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
    printf("-------ENCRYPTED FILE-------\n");
    for (int i = 0; i < file_size; i++)
    {
        for (int j = 0; j < file_size; j++)
        {
            printf("%d ", encrypt[i][j]);
        }
        printf("\n");
    }
}



void parse_server_args(int argc, char *argv[], int *j, int *s, int *p)
{
    int opt;
    while ((opt = getopt(argc, argv, "j:s:p:")) != -1)
    {
        switch (opt)
        {
        case 'j':
            *j = atoi(optarg);
            break;
        case 's':
            if (atoi(optarg) && (!(atoi(optarg) & (atoi(optarg) - 1))))
            {
                *s = atoi(optarg);
            }
            else
            {
                printf("The file size must be a power of 2\n");
                exit(0);
            }
            break;
        case 'p':
            *p = atoi(optarg);
            break;
        case ':':
            printf("option needs a value\n");
            break;
        case '?':
            printf("unknown option: %c\n", optopt);
            break;
        }
    }
}


void parse_client_args(int argc, char *argv[], int *k, int *r, int *t, char **serv_addr, int *port)
{
    int opt;
    while ((opt = getopt(argc, argv, "k:r:t:")) != -1)
    {
        switch (opt)
        {
        case 'k':
            if (atoi(optarg) && (!(atoi(optarg) & (atoi(optarg) - 1))))
            {
                *k = atoi(optarg);
            }
            else
            {
                printf("The key size must be a power of 2\n");
                exit(0);
            }
            break;
        case 'r':
            *r = atoi(optarg);
            break;
        case 't':
            *t = atoi(optarg);
            break;
        case ':':
            printf("option needs a value\n");
            break;
        case '?':
            printf("unknown option: %c\n", optopt);
            break;
        }
    }
    for (; optind < argc; optind++)
    {
        *serv_addr = strtok(argv[optind], ":");
        *port = atoi(strtok(NULL, ":"));
    }
}