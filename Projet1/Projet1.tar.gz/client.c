#include <arpa/inet.h> // inet_addr()
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h> // bzero()
#include <sys/socket.h>
#include "utils.h"
#include <unistd.h> // read(), write(), close()
#include <time.h>
#include "functions.c"

#define SA struct sockaddr
int send_request(int sockfd, int requested_file, int key[], int key_size)
{
    struct client_pkt *pkt_to_send = malloc(sizeof(struct client_pkt));
    pkt_to_send->index = htonl(requested_file);
    pkt_to_send->key_size = htonl(key_size);

    write(sockfd, pkt_to_send, sizeof(pkt_to_send));
    for (int i = 0; i < key_size; i++)
    {
        key[i] = htonl(key[i]);
    }
    write(sockfd, key, key_size * sizeof(int) * key_size);
    
    free(pkt_to_send);
    return 0;
}
int send_end_request(int sockfd){
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    struct client_pkt *end_pkt = malloc(sizeof(struct client_pkt));
    end_pkt->index = htonl(0);
    end_pkt->key_size = htonl(0);
    write(sockfd,end_pkt,sizeof(end_pkt));
    free(end_pkt);
}

int main(int argc, char *argv[])
{
    int opt;
    int key_size = 2;
    int mean_rate = 1000;
    int duration = 1;
    int port = 8080;
    char *server_addr = "127.0.0.1";
    int sockfd, connfd;
    struct sockaddr_in servaddr, cli;
    int test = 0;

    srand(time(NULL));
    // Parse all args
    parse_client_args(argc, argv, &key_size, &mean_rate, &duration, &server_addr, &port);
    for (int i = 0; i <= duration * mean_rate; i++){
        // Try to connect the socket
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd == -1)
        {
            printf("Socket creation failed\n");
            exit(0);
        }
        bzero(&servaddr, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr(server_addr);
        servaddr.sin_port = htons(port);

        // connect the client socket to server socket
        if (connect(sockfd, (SA *)&servaddr, sizeof(servaddr)) != 0)
        {
            printf("Connection with the server failed...\n");
            exit(0);
        }
        int *key;
        key = malloc(key_size * key_size * sizeof(int));
        // Send multiple requests
        for (int j = 0; j < key_size * key_size; j++)
        {
            key[j] = rand() % 256;
        }
        int index = 1 + rand()%1000;
        printf("Send request: %d with index:%d\n",test++,index);
        send_request(sockfd, index, key, key_size);
        if (mean_rate > 999)
            usleep(1000 / (mean_rate / 1000));
        else
            usleep(1000);
        free(key);
        close(sockfd);
    }
    printf("Send last packet\n");
    send_end_request(sockfd);
}