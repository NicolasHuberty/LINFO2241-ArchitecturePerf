#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <signal.h>
#include <sys/types.h>
#include "utils.h"
#include <unistd.h>
#include "functions.c"
#include <pthread.h>
#include <semaphore.h>
#define MAX 80
#define PORT 8080
#define SIZE 1024
//ONEDRIVE VERSION
#define SA struct sockaddr
struct arg_struct{
    struct client_pkt* pkt;
    int socket;
}arguments;
volatile uint8_t ***files;
int size_of_file = 4;
int connfd;
sem_t x,y;
pthread_t tid;
pthread_t readerthreads[100];
int readercount = 0;
void *func(struct arg_struct* arguments){
    sem_wait(&x);
    readercount++;
    if(readercount == 1){
        sem_wait(&y);
    }
    sem_post(&x);
    struct client_pkt* pkt_rcv = arguments->pkt;
    int connfd = arguments->socket;
    printf("Start the job\n");
    pkt_rcv->index = ntohl(pkt_rcv->index);
    printf("Index receive: %d\n",pkt_rcv->index);
    pkt_rcv->key_size = ntohl(pkt_rcv->key_size);
    if(pkt_rcv->key_size==0 && pkt_rcv->index == 0){
        return (void*)1;
    }
    // Check if the packet is valid
    if (pkt_rcv->index > 999 || pkt_rcv->index <= 0 ||(pkt_rcv->key_size == 0) || ((pkt_rcv->key_size & (pkt_rcv->key_size - 1)) != 0)){
        free(pkt_rcv);
        return (void*)-1;
    }
    int *key = malloc(pkt_rcv->key_size * pkt_rcv->key_size * sizeof(int));
    read(connfd, key, pkt_rcv->key_size * pkt_rcv->key_size * sizeof(int));
    // Transform the key in host endianness
    for (int i = 0; i < pkt_rcv->key_size; i++){
        key[i] = ntohl(key[i]);
    }
    uint8_t **encrypted = encryption(key, files[pkt_rcv->index], size_of_file, pkt_rcv->key_size);
    // Write
    struct server_pkt *pkt_to_send = malloc(sizeof(struct server_pkt));
    pkt_to_send->error = htonl(0);
    pkt_to_send->file_size = htonl(size_of_file*size_of_file);
    write(connfd, pkt_to_send, sizeof(pkt_to_send));
    print_data(key, files[pkt_rcv->index], encrypted, size_of_file, pkt_rcv->key_size);

    // Transform encrypted tab in network endianness
    for (size_t i = 0; i < size_of_file; i++){
        for (size_t j = 0; j < size_of_file; j++){
            encrypted[i][j] = htonl(encrypted[i][j]);
        }
    }
    write(connfd, encrypted, size_of_file * sizeof(int));
    for (int i = 0; i < size_of_file; i++){
        free(encrypted[i]);
    }
    printf("End job\n");
    free(encrypted);
    free(key);
    free(pkt_rcv);
    free(pkt_to_send);
    free(arguments);
    close(connfd);
    sem_wait(&x);
    readercount--;
    if(readercount==0)sem_post(&y);
    sem_post(&x);
    printf("Thread just ended\n");
    pthread_exit(NULL);
}

// Driver function
int main(int argc, char **argv){
    int port = 8080;
    int nb_threads = 1;
    int serverSocket, newSocket;
    struct sockaddr_in serverAddr;
    struct sockaddr_storage serverStorage;
    socklen_t addr_size;
    parse_server_args(argc, argv, &nb_threads, &size_of_file, &port);
    files = generateFiles(size_of_file);
    sem_init(&x, 0, 1);
    sem_init(&y, 0, 1);
    //memset(&serverSocket, 0, sizeof(serverSocket));
    serverSocket = socket(AF_INET,SOCK_STREAM,0);
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(8080);
    if((bind(serverSocket,(struct sockaddr*)&serverAddr, sizeof(serverAddr))) != 0){
        printf("socket bind failed...\n");
        exit(0);
    }

    if(listen(serverSocket,50) == 0){
        printf("Listening new connection\n");
    }else printf("Error while Listening\n");
    pthread_t tid[60];
    int i = 0;


    // Function for chatting between client and server
    while (1){
        addr_size = sizeof(serverStorage);
        //Take first connection in the queue
        newSocket = accept(serverSocket,(struct sockaddr*)&serverStorage,&addr_size);
        printf("Launch a new thread\n");
        struct arg_struct *arguments = malloc(sizeof(struct arg_struct));
        arguments->pkt = malloc(sizeof(struct client_pkt));
        arguments->socket = newSocket; 
        recv(newSocket, arguments->pkt, sizeof(arguments->pkt),0);
        printf("Index: %d and key size: %d\n",ntohl(arguments->pkt->index),ntohl(arguments->pkt->key_size));
        if(ntohl(arguments->pkt->index)==0 && ntohl(arguments->pkt->key_size) == 0){
            printf("ENNNNDDDDDD\n");
            break;
        }
        if(pthread_create(&readerthreads[i++],NULL,(void*)func,(void*)arguments) != 0){
            printf("Failed to create a new thread\n");
            return 0;
        }
        if(i>=50){
            i = 0;
            while(i < 50){
                pthread_join(readerthreads[i++],NULL);
            }
            i = 0;
        }
        
    }

    printf("close correctly\n");
    free(files);
    return 0;
}